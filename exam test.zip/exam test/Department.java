import java.util.Scanner;

public class Department {

    public static void main(String[] args) {
        System.out.println("***Welcome to explore with Fun Game***");
        System.out.println("Select From The Main Menu");
        System.out.println("1. Print Hollow Nirroed Rhombus");
        System.out.println("2. Revers your Name");
        System.out.println("3. Find Vowels in your name");
        System.out.println("4. Revers a Number");
        System.out.println("5. Revers an Array");
        System.out.println("6. GCD of Two Nmbers");

        System.out.println("Enter choose number (1 to 6) :- ");
        Scanner scanner = new Scanner(System.in);
        int choose = scanner.nextInt();

        if (choose == 1) {

            System.out.println("Enter the number of rows:-");
            Scanner scanner1 = new Scanner(System.in);
            int row = scanner1.nextInt();

            System.out.println("Enter the number of colloms:-");
            Scanner scanner2 = new Scanner(System.in);
            int colloms = scanner2.nextInt();

            System.out.println("Enter the Symbol:-");
            Scanner scanner3 = new Scanner(System.in);
            char symbel = scanner3.next().charAt(0);

            // for(int i=1;i<=scanner1;i++)
            // {
            // for(int j=1;j<=scanner1-i;j++)

            // {
            // System.out.print(" ");
            // }
            // for(int j=1;j<=scanner1;j++)

            // {
            // System.out.print(c);
            // }

            // System.out.println();

            // }2

        }

        else if (choose == 2) {

            System.out.println("Enter name or String to Reverse it: ");
            Scanner rev = new Scanner(System.in);
            String name = rev.nextLine();
            StringBuilder reversed = new StringBuilder();

            for (int i = name.length() - 1; i >= 0; i--) {
                reversed.append(name.charAt(i));
            }

            System.out.println(reversed.toString());
        }

        // }
        else if (choose == 3) {

            System.out.println("Enter your name:- ");
            Scanner name = new Scanner(System.in);
            String enter = name.nextLine();

            // char enter = 'a'; // Change this character to check for vowels

            // Convert the character to lowercase to handle both uppercase and lowercase
            // vowels
            // int vowelCount = 0;

            for (int i = 0; i < enter.length(); i++) {
                char currentChar = enter.charAt(i);
                if (currentChar == 'a' || currentChar == 'e' || currentChar == 'i' || currentChar == 'o'
                        || currentChar == 'u') {
                    System.out.println("Number of vowels: " + currentChar);
                }
            }
            // System.out.println("Number of vowels: " + vowelCount);
        }

        else if (choose == 4) {
            Scanner scan = new Scanner(System.in);

            // Prompt the user for the number of elements
            System.out.print("Enter the number of elements: ");
            int n = scan.nextInt();

            // Create an array to store the numbers
            int[] numbers = new int[n];

            // Prompt the user to enter each number
            for (int i = 0; i < n; i++) {
                System.out.print("Enter number " + (i + 1) + ": ");
                numbers[i] = scan.nextInt();
            }

            scanner.close();

            // Display the numbers in reverse order
            System.out.println("Numbers in reverse order:");
            for (int i = n - 1; i >= 0; i--) {
                System.out.println(numbers[i]);
            }
        }
    }
}
// else if(choose == 5 ){

// }
// else(choose == 6 ){

// }

// }
