class AddingNumbers {

    int number1;
    int number2;

    public AddingNumbers(int number1, int number2) {
        this.number1 = number1;
        this.number2 = number2;

    }

    public void Display_Inputs(){
        System.out.println("Number 1: "+number1);
        System.out.println("Number 2: "+number2");
    
       }

}

class AddingNumbers extends AddingNumbers {
