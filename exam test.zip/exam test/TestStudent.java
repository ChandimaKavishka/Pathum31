
class Student {
    String StdNumber;
    String Name;

    Student(String no, String n) {
        this.StdNumber = no;
        this.Name = n;

    }

    void display() {
        System.out.println("Student Number : " + StdNumber);
        System.out.println("Student Name : " + Name);

    }
}

class ITStudent extends Student {

    int mark1;
    int mark2;
    int total;
    double Average;

    ITStudent(String no, String n, int m1, int m2) {
        super(no, n);
        this.mark1 = m1;
        this.mark2 = m2;

    }

    void calculation() {
        int total = mark1 + mark2;

        Average = total / 2.0;
    }

    void display() {
        super.display();

        System.out.println("Total is : " + total);
        System.out.println("Total is : " + Average);

    }
}

class TestStudent {
    public static void main(String[] args) {
        ITStudent obj1 = new ITStudent("01", "chandima", 10, 20);

        obj1.calculation();
        obj1.display();
    }
}
