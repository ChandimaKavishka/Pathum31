
class Student {
    String StdNumber;
    String Name;
}