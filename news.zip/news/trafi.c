
void main() {


       TRISB = 0;
       TRISD = 0;


while(1){
PORTB.RB0 = 0;
PORTB.RB1 = 0;
PORTB.RB2 = 0;

PORTB.RB5 = 0;
PORTB.RB6 = 0;
PORTB.RB7 = 0;

PORTB.RD0=0;
PORTB.RD1=0;
PORTB.RD2=0;

PORTC.RD5=0;
PORTC.RD6=0;
PORTC.RD7=0;

PORTB.RB0 =0;
PORTB.RB1 = 0;
PORTB.RB2=1;




//PORTD.A0=0;
//PORTD.A1=0;
//PORTD.A2=1;

   delay_ms(1000);

PORTB.RD0=0;
PORTB.RD1=1;
delay_ms(1000);
PORTB.RD2=0;

PORTB.RB5 = 0;
PORTB.RB6 = 0;
PORTB.RB7 = 1;

PORTC.RD5=0;
PORTC.RD6=1;
PORTC.RD7=0;


  }
}