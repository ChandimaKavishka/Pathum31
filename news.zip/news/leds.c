void interrupt(){
if(INTCON.INTF){

PORTD.F7 = 1;

if(PORTB.F0 == 0){5

PORTD.F7 = 0;
INTCON.INTF = 0;

}
}
}
 void main(){
 TRISD = 0x00;
 PORTD = 0x00;
 delay_ms(100);
 

 TRISD.F0=0;
 PORTD.F0=1;
 
 INTCON.GIE = 1;
 INTCON.INTE = 1;
 INTCON.INTF = 0;
 
 while(1){
 
 PORTD.F0=1;
 delay_ms(20);
 
 PORTD.F1=1;
 delay_ms(20);
 
  PORTD.F2=1;
 delay_ms(20);
 
  PORTD.F3=1;
 delay_ms(20);
 
  PORTD.F0=0;
 delay_ms(20);
 
  PORTD.F1=0;
 delay_ms(20);
 
  PORTD.F2=0;
 delay_ms(20);
 
 PORTD.F3=0;
 delay_ms(20);
 }
  }
