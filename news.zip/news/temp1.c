
sbit LCD_RS at RB2_bit;
sbit LCD_EN at RB3_bit;
sbit LCD_D4 at RB4_bit;
sbit LCD_D5 at RB5_bit;
sbit LCD_D6 at RB6_bit;
sbit LCD_D7 at RB7_bit;

sbit LCD_RS_Direction at TRISB2_bit;
sbit LCD_EN_Direction at TRISB3_bit;
sbit LCD_D4_Direction at TRISB4_bit;
sbit LCD_D5_Direction at TRISB5_bit;
sbit LCD_D6_Direction at TRISB6_bit;
sbit LCD_D7_Direction at TRISB7_bit;

char display[16];

void main()     {

float result,temp,volt;
TRISD = 0;
ADCON1.RA1 = 1;

           ADC_Init();
           LCD_Init();
           LCD_Cmd(_LCD_CLEAR);
           LCD_Cmd(_LCD_CURSOR_OFF);
           
           while(1){
           
           result = ADC_Read(1);
           volt = (result*5000)/1024;
           temp = volt/10;
z           floatToStr(temp,display);
           
           Lcd_Out(2,1,"temp");
           Lcd_Out(2,8,display);
           
           if(temp>25.00){
           
           PORTD.RDO = 1;
           PORTD.RD1 = 0;
           
           }
           else{
               PORTC.RC0 = 0;
               PORTC.RC1 = 0;
           }
           

           }

}