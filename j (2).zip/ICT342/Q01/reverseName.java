import java.util.Scanner;
public class reverseName {

    public static void main(String[]args)
    {
        String str;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter a Name: ");
        str=scan.nextLine();
        char[] ch=str.toCharArray();
        System.out.println("Reverse of a Name is : ");
        int j=ch.length;
        for(int i=j;i>0;i--)
        {
            System.out.println(ch[i-1]);
        }
    }
     
}