import java.util.Scanner;
class GCD {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        
        System.out.print("Enter first number: ") ;  
        int a = sc.nextInt();  
        System.out.print("Enter second number: ");  
        int b = sc.nextInt();  
        
        int GCD = 1;
        
        if (a==0) GCD = b;
        if (b==0) GCD = a;

        for(int i=1; i<Math.min(a,b); i++)
            
            if(a%i==0 && b%i==0)
                GCD = i; 
        
        System.out.println("GCD(" + a + ", " + b + ") = " + GCD);
    }
}
