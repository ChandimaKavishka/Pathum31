import java.util.Scanner;

public class FunGameMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("*** Welcome to Explore with Fun Game ***");
        System.out.println("\nSELECT FROM THE MAIN MENU\n");
        System.out.println("1. Print Hollow Mirrored Rhombus");
        System.out.println("2. Reverse Your Name");
        System.out.println("3. Find Vowels in Your Name");
        System.out.println("4. Reverse a Number");
        System.out.println("5. Reverse an Array");
        System.out.println("6. GCD of Two Numbers");

        System.out.print("\nEnter your choice (1-6): ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:

                printHollowMirroredRhombus();
                break;
            case 2:

                reverseYourName();
                break;
            case 3:

                findVowelsInYourName();
                break;
            case 4:

                reverseANumber();
                break;
            case 5:

                reverseAnArray();
                break;
            case 6:

                findGCDOfTwoNumbers();
                break;
            default:
                System.out.println("Invalid choice. Please select a number between 1 and 6.");
        }

        scanner.close();
    }


    private static void printHollowMirroredRhombus() {

        System.out.println("You selected option 1: Print Hollow Mirrored Rhombus");

    }

    private static void reverseYourName() {

        System.out.println("You selected option 2: Reverse Your Name");

    }

    private static void findVowelsInYourName() {

        System.out.println("You selected option 3: Find Vowels in Your Name");

    }

    private static void reverseANumber() {

        System.out.println("You selected option 4: Reverse a Number");

    }

    private static void reverseAnArray() {

        System.out.println("You selected option 5: Reverse an Array");

    }

    private static void findGCDOfTwoNumbers() {

        System.out.println("You selected option 6: GCD of Two Numbers");

    }
}
