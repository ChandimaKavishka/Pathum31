import java.util.Scanner;
public class Rhombuss {

    public static void main(String[] args)
    {
             
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter N : ");
	int n=sc.nextInt();	 
              System.out.print("Enter Symbol : ");
	
              char c = sc.next().charAt(0);

	for(int i=1;i<=n;i++)
               {

                        for(int j=i;j>0;j--)
                
                        {
                               System.out.print(" ");
                        }
	     if(i==1 || i==n)
                       for(int j=1;j<=n;j++)
                
                        {
                               System.out.print(c);
                        }
                   else
	    {
                	       for(int j=1;j<=n;j++)
                
                	       {  
                            		if(j==1 || j==n)
                               	System.out.print(c);
                              	else
                             
                            	               System.out.print(" ");
                                   }
                     }
                            System.out.println();
                       
               }             

 
                
    }
}


//triangle
public class RightTrianglePattern 
{ 
public static void main(String args[]) 
{ 
//i for rows and j for columns 
//row denotes the number of rows you want to print 
int i, j, row=6; 
//outer loop for rows 
for(i=0; i<row; i++) 
{ 
//inner loop for columns 
for(j=0; j<=i; j++) 
{ 
//prints stars 
System.out.print("* "); 
} 
//throws the cursor in a new line after printing each line 
System.out.println(); 
} 
} 
} 