abstract class Calculation {
    abstract void calculate(int a, int b);
}


class Addition extends Calculation {
    @Override
    void calculate(int a, int b) {
        System.out.println("Addition Result: " + (a + b));
    }
}


class Subtraction extends Calculation {
    @Override
    void calculate(int a, int b) {
        System.out.println("Subtraction Result: " + (a - b));
    }
}


class Multiplication extends Calculation {
    @Override
    void calculate(int a, int b) {
        System.out.println("Multiplication Result: " + (a * b));
    }
}

class Division extends Calculation {
    @Override
    void calculate(int a, int b) {
        if (b != 0) {
            System.out.println("Division Result: " + ((double) a / b));
        } else {
            System.out.println("Cannot divide by zero!");
        }
    }
}

public class CalculationMain {
    public static void main(String[] args) {
        Addition add = new Addition();
        Subtraction subt = new Subtraction();
        Multiplication mult = new Multiplication();
        Division div = new Division();

        add.calculate(10, 5);
        subt.calculate(10, 5);
        mult.calculate(10, 5);
        div.calculate(10, 5);

        div.calculate(10, 0);
    }
}
