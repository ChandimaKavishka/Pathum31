class A {
    public void method() {
        System.out.println("Method in class A without parameters");
    }
}

class B extends A {
    public void method(int x) {
        System.out.println("Method in class B with parameter (int): " + x);
    }
}

class C extends B {
    public void method(double y) {
        System.out.println("Method in class C with parameter (double): " + y);
    }
}

public class Main {
    public static void main(String[] args) {

        A objA = new A();
        B objB = new B();
        C objC = new C();

        objA.method();
        objB.method(10);
        objC.method(15.5);


        objB.method();
        objC.method();
    }
}
