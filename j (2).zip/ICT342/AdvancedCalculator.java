class Calculator {
    public int add(int a, int b) {
        return a + b;
    }

    public int sub(int a, int b) {
        return a - b;
    }
}

class AdvancedCalculator extends Calculator {
    public int mul(int a, int b) {
        return a * b;
    }

    public double div(int a, int b) {
        if (b != 0) {
            return (double) a / b;
        } else {
            System.out.println("Cannot divide by zero!");
            return Double.NaN;
        }
    }
}

public class CalculatorMain {
    public static void main(String[] args) {
        AdvancedCalculator myCalculator = new AdvancedCalculator();

        System.out.println("Addition: " + myCalculator.add(5, 3));
        System.out.println("Subtraction: " + myCalculator.sub(10, 4));
        System.out.println("Multiplication: " + myCalculator.mul(6, 7));
        System.out.println("Division: " + myCalculator.div(20, 4));
        System.out.println("Division by zero: " + myCalculator.div(10, 0));
    }
}
