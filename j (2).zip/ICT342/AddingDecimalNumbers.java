class AddingNumbers {

    int number1;
    int number2;

    public AddingNumbers(int number1, int number2) {
        this.number1 = number1;
        this.number2 = number2;

    }

    public void Display_Inputs() {
        System.out.println("Number 1: " + number1);
        System.out.println("Number 2: " + number2);
    }

}

class AddingBinaryNumbers extends AddingNumbers {
    public AddingBinaryNumbers(int number1, int number2) {
        super(number1, number2);

    }

    public String addBinary() {

        int sum = number1 + number2;
        return Integer.toBinaryString(sum);

    }

}

public class AddingDecimalNumbers extends AddingNumbers {
    public AddingDecimalNumbers(int number1, int number2) {
        super(number1, number2);

    }

    public int addDecimal() {
        return number1 + number2;

    }
}

class MyEntry {
    public static void main(String[] args) {

        AddingBinaryNumbers addBinary = new AddingBinaryNumbers(10, 11);
        String binaryResult = addBinary.addBinary();
        System.out.println("Binary sum: " + binaryResult);

        AddingDecimalNumbers addDecimal = new AddingDecimalNumbers(10, 20);
        int DecimalResult = addDecimal.addDecimal();
        System.out.println("Decimal sum: " + DecimalResult);

        AddingNumbers obj3 = new AddingNumbers(10, 15);
        obj3.Display_Inputs();

    }

}